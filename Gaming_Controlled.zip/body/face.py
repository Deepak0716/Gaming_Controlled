from .events import Events  # Import Events class from the events module
from .utils import get_side_facing  # Import get_side_facing function from the utils module

class FaceState:
    # Class-level constant for the maximum tilt angle
    TILT_SLOPE_ANGLE = 35

    # Constructor method
    def __init__(self):
        # Initialize attributes to None
        self.tilt_direction = None  # Initialize tilt_direction attribute
        self.side_facing = None  # Initialize side_facing attribute

    # Method to update the face state
    def update(
        self,
        mode: str,
        events: Events,
        nose,
        left_eye,
        right_eye,
        left_ear,
        right_ear,
        mouth_left,
        mouth_right,
        left_shoulder,
        right_shoulder,
        left_right_eyes_slope,
    ):
        if mode == "Driving":  # If in driving mode, return early without updating
            return

        # Check the tilt direction based on the slope of the line connecting the eyes
        if left_right_eyes_slope > self.TILT_SLOPE_ANGLE:
            self.tilt_direction = "left"
            events.add("face_tilt_left")  # Add face tilt left event to the events pipeline
        elif left_right_eyes_slope < -self.TILT_SLOPE_ANGLE:
            self.tilt_direction = "right"
            events.add("face_tilt_right")  # Add face tilt right event to the events pipeline
        else:
            self.tilt_direction = None  # Reset tilt direction if within tolerance

        # Determine the side facing based on the relative positions of ears and shoulders
        self.side_facing = get_side_facing(
            [[right_ear, left_ear], [right_shoulder, left_shoulder]]
        )

    # String representation of FaceState object
    def __str__(self):
        return f"Side facing: {self.side_facing}"  # Return the side facing information
