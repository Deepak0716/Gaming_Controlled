# Define a constant representing the width of the image
IMAGE_WIDTH = 640

# Define a constant representing the height of the image
IMAGE_HEIGHT = 480

# Define a dictionary representing the driving up area with its coordinates and dimensions
DRIVING_UP_AREA = dict(x=250, y=200, width=170, height=150)
# x: The x-coordinate of the top-left corner of the driving up area
# y: The y-coordinate of the top-left corner of the driving up area
# width: The width of the driving up area
# height: The height of the driving up area
