from .command import CommandProcessor  # Import the CommandProcessor class from the command module

class Events:
    # Constructor method
    def __init__(
        self,
        keyboard_enabled,
        cross_cmd_enabled,
        pressing_timer_interval,
        d1_pressing_timer_interval,
        d2_pressing_timer_interval,
        command_key_mappings,
        asphalt9_mappings=None,  # Add asphalt9_mappings as a keyword argument with a default value of None
    ):
        # Initialize attributes with provided arguments
        self.keyboard_enabled = keyboard_enabled
        self.cross_cmd_enabled = cross_cmd_enabled
        self.command_key_mappings = command_key_mappings
        self.pressing_timer_interval = pressing_timer_interval
        self.d1_pressing_timer_interval = d1_pressing_timer_interval
        self.d2_pressing_timer_interval = d2_pressing_timer_interval
        self.asphalt9_mappings = asphalt9_mappings  # Store asphalt9_mappings as an instance attribute

        # Initialize CommandProcessor instances for different types of commands
        self.cmd_process = CommandProcessor()  # For general commands
        self.d1_cmd_process = CommandProcessor()  # For direction 1 (e.g., walk)
        self.d2_cmd_process = CommandProcessor()  # For direction 2 (e.g., face)

    # Method to set an attribute of the Events instance
    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Method to get the value of an attribute of the Events instance
    def __getitem__(self, key):
        return getattr(self, key)

    # Method to toggle keyboard events if encountering cross hands command
    def check_cross_command(self, command):
        if self.cross_cmd_enabled and command == "cross":  # Check if cross command is enabled and encountered
            # Toggle keyboard events
            self.keyboard_enabled = not self.keyboard_enabled
            # Release any previously pressed keys
            self.cmd_process.release_previous_key()
            self.d1_cmd_process.release_previous_key()
            self.d2_cmd_process.release_previous_key()

    # Method to add a command to the pipeline
    def add(self, command):
        self.check_cross_command(command)  # Check if the command is a cross command

        # Split command by type and add it to the appropriate CommandProcessor instance
        if "walk" in command or "d1" in command:  # If it's a direction 1 command
            self.d1_cmd_process.add_command(
                command,
                self.keyboard_enabled,
                self.command_key_mappings,
                self.d1_pressing_timer_interval,
            )
        elif "face" in command or "d2" in command:  # If it's a direction 2 command
            self.d2_cmd_process.add_command(
                command,
                self.keyboard_enabled,
                self.command_key_mappings,
                self.d2_pressing_timer_interval,
            )
        else:  # For general commands
            self.cmd_process.add_command(
                command,
                self.keyboard_enabled,
                self.command_key_mappings,
                self.pressing_timer_interval,
            )

    # String representation of Events object
    def __str__(self):
        # Construct string representation with counts of commands processed by each CommandProcessor instance
        return f"""
D1 ({len(self.d1_cmd_process.commands)}): {self.d1_cmd_process}

D2 ({len(self.d2_cmd_process.commands)}): {self.d2_cmd_process}

Events ({len(self.cmd_process.commands)}): {self.cmd_process}"""
