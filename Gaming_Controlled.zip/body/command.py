from datetime import datetime  # Import datetime module to work with dates and times
from pynput.keyboard import Controller  # Import Controller class from pynput.keyboard module for controlling keyboard
from threading import Timer  # Import Timer class from threading module for timing events


class CommandProcessor:
    def __init__(self):
        self.keyboard = Controller()  # Initialize keyboard controller
        self.commands = []  # Initialize empty list to store commands
        self.pressing_key = None  # Initialize pressing_key attribute to None
        self.pressing_timer = None  # Initialize pressing_timer attribute to None

    # Method to release the previous key that was pressed
    def release_previous_key(self):
        if self.pressing_key:
            previous_key = self.pressing_key["key"]
            self.keyboard.release(previous_key)  # Release the key
            self.pressing_key = None

    # Method to limit the number of commands stored
    def limit_commands(self):
        if len(self.commands) > 900:  # If the number of commands exceeds 900
            self.commands = self.commands[-10:]  # Keep only the last 10 commands

    # Method to add a command to the list of commands
    def add_command(
        self,
        command,
        keyboard_enabled: bool,
        command_key_mappings: dict,
        pressing_timer_interval: float,
    ):
        self.limit_commands()  # Limit the number of stored commands

        now = datetime.now()  # Get the current date and time
        self.commands.insert(0, dict(command=command, time=now))  # Insert command with timestamp at the beginning of the list

        if keyboard_enabled:  # If keyboard control is enabled
            if command in command_key_mappings:  # If the command has a key mapping
                key = command_key_mappings[command]  # Get the key associated with the command

                # Get the previous key that was pressed
                previous_key = None
                if self.pressing_key:
                    previous_key = self.pressing_key["key"]

                # Clear the old timer if it's still running
                if self.pressing_timer and self.pressing_timer.is_alive():
                    self.pressing_timer.cancel()

                # Perform key press/release actions
                if previous_key != key:  # If the current key is different from the previous key
                    self.release_previous_key()  # Release the previous key
                    if key:  # If the new key exists
                        self.keyboard.press(key)  # Press the new key

                if key:  # If the key exists
                    # Create a new timer to release the key after a certain interval
                    self.pressing_timer = Timer(
                        pressing_timer_interval,
                        self.release_previous_key,
                    )
                    self.pressing_timer.start()  # Start the timer

                    self.pressing_key = dict(key=key, time=now)  # Store the current key and timestamp

    # String representation of CommandProcessor object
    def __str__(self):
        commands_list = list(map(lambda c: c["command"], self.commands))  # Extract commands from the list of commands
        if not commands_list:  # If the list of commands is empty
            return ""  # Return an empty string
        return commands_list[0] + "\n" + ", ".join(commands_list[1:20])  # Return the first command followed by the next 19 commands (if available)
