from .events import Events

class LegState:
    def __init__(self, side):
        self.side = side
        self.straight = None  # Initialize the 'straight' attribute

    def update(self, events: Events, hip, knee, ankle, hip_angle, knee_angle):
        # Update the 'straight' attribute based on knee angle
        self.straight = knee_angle > 160

    def __str__(self):
        # Construct a string representation of LegState object
        states = ("straight" if self.straight else "",)  # Include 'straight' state if true
        states = filter(lambda s: s != "", states)  # Filter out empty states
        return ", ".join(states)  # Join states into a single string

class LegsState:
    # Constants
    KNEE_UP_MAX_ANGLE = 155
    KNEE_MIN_VISIBILITY = 0.5

    def __init__(self):
        # Initialize left and right LegState objects
        self.left = LegState("left")
        self.right = LegState("right")

        # Initialize state attributes
        self.left_up_state = False
        self.right_up_state = False
        self.squat = False
        self.steps = 0

    def update(
        self,
        mode: str,
        events: Events,
        left_hip,
        right_hip,
        left_knee,
        right_knee,
        left_ankle,
        right_ankle,
        left_hip_angle,
        right_hip_angle,
        left_knee_angle,
        right_knee_angle,
    ):
        # Update left and right LegState objects
        self.left.update(
            events,
            left_hip,
            left_knee,
            left_ankle,
            left_hip_angle,
            left_knee_angle,
        )
        self.right.update(
            events,
            right_hip,
            right_knee,
            right_ankle,
            right_hip_angle,
            right_knee_angle,
        )

        # Check mode and knee visibility
        if mode == "Driving":
            return

        if (
            left_knee[3] > self.KNEE_MIN_VISIBILITY
            and right_knee[3] > self.KNEE_MIN_VISIBILITY
        ):
            # Check if both knees are bent to consider squatting
            if (
                left_knee_angle < self.KNEE_UP_MAX_ANGLE
                and right_knee_angle < self.KNEE_UP_MAX_ANGLE
            ):
                if not self.squat:
                    self.squat = True
                    events.add("squat")
            else:
                self.squat = False

            if self.squat:
                return

            # Update left and right leg up states
            if left_knee_angle < self.KNEE_UP_MAX_ANGLE:
                if not self.left_up_state:
                    self.left_up_state = True
                    self.steps += 1
            else:
                self.left_up_state = False

            if right_knee_angle < self.KNEE_UP_MAX_ANGLE:
                if not self.right_up_state:
                    self.right_up_state = True
                    self.steps += 1
            else:
                self.right_up_state = False

    def __str__(self):
        # Construct a string representation of LegsState object
        return f"steps: {self.steps}"  # Return the number of steps
