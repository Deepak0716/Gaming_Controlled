import cv2
from .events import Events
from .utils import (
    compare_nums,
    is_landmarks_closed,
    calculate_slope,
    calculate_distance,
    in_range,
    is_landmarks_in_rectangle,
)
from .const import IMAGE_HEIGHT, IMAGE_WIDTH, DRIVING_UP_AREA


class ArmState:
    # Maximum angle for the elbow to consider it curled
    CURL_MAX_ANGLE = 45  

    def __init__(self, side):
        # Initialize ArmState with side (left or right)
        self.side = side  

        # Initialize state variables for the arm
        self.straight = None  # Whether the arm is straight or not
        self.curl = None  # Whether the arm is curled or not
        self.up = None  # Whether the arm is raised up or not
        self.front = None  # Whether the arm is in front or back
        self.raised = None  # Whether the arm is raised or not

    @property
    def is_left(self):
        # Check if the arm is left
        return self.side == "left"  

    def update(
        self,
        events: Events,
        shoulder,
        elbow,
        wrist,
        pinky,
        index,
        thumb,
        shoulder_angle,
        elbow_angle,
    ):
        # Update the state of the arm based on landmarks and angles
        self.straight = elbow_angle > 160  # Check if the arm is straight
        self.up = shoulder_angle > 45  # Check if the arm is raised
        self.front = wrist[2] > shoulder[2]  # Check if the arm is in front
        self.curl = elbow_angle < self.CURL_MAX_ANGLE  # Check if the arm is curled
        self.raised = wrist[1] < shoulder[1]  # Check if the arm is raised relative to shoulder

    def __str__(self):
        # Convert the arm state to a human-readable string
        states = (
            "straight" if self.straight else "",
            "curl" if self.curl else "",
            "up" if self.up else "down",
            "front" if self.front else "back",
        )
        states = filter(lambda s: s != "", states)  # Remove empty strings
        return ", ".join(states)  # Join non-empty strings


class ArmsState:
    # Maximum angle for elbows to consider arms crossed
    ELBOW_CROSS_MAX_ANGLE = 60  
    # Slope angle for driving mode
    DRIVING_SLOPE_ANGLE = 25  

    def __init__(self):
        # Initialize left and right arm states
        self.left = ArmState("left")
        self.right = ArmState("right")

        # Initialize state variables for arms
        self.crossed = None  # Whether the arms are crossed or not
        self.left_swing = None  # Whether left arm is swinging
        self.left_swing_up = None  # Whether left arm is swinging up
        self.right_swing = None  # Whether right arm is swinging
        self.right_swing_up = None  # Whether right arm is swinging up
        self.hold_hands = None  # Whether hands are being held
        self.driving_hands = None  # Whether hands are in driving position

    def update(
        self,
        mode: str,
        image,
        events: Events,
        nose,
        left_shoulder,
        right_shoulder,
        left_elbow,
        right_elbow,
        left_wrist,
        right_wrist,
        left_pinky,
        right_pinky,
        left_index,
        right_index,
        left_thumb,
        right_thumb,
        left_shoulder_angle,
        right_shoulder_angle,
        left_elbow_angle,
        right_elbow_angle,
    ):
        # Update left and right arm states
        self.left.update(
            events,
            left_shoulder,
            left_elbow,
            left_wrist,
            left_pinky,
            left_index,
            left_thumb,
            left_shoulder_angle,
            left_elbow_angle,
        )
        self.right.update(
            events,
            right_shoulder,
            right_elbow,
            right_wrist,
            right_pinky,
            right_index,
            right_thumb,
            right_shoulder_angle,
            right_elbow_angle,
        )

        left_right_hands_slope = calculate_slope(left_thumb, right_thumb)

        if mode == "Driving":
            # Update state for driving mode
            if is_landmarks_closed(
                [
                    left_pinky,
                    right_pinky,
                    left_index,
                    right_index,
                    left_thumb,
                    right_thumb,
                ],
                0.3,
            ):
                # If hands are closed in driving position
                self.driving_hands = True

                # Draw circle on the image representing driving position
                cv2.circle(
                    image,
                    (
                        int((left_thumb[0] + right_thumb[0]) / 2 * IMAGE_WIDTH),
                        int((left_thumb[1] + right_thumb[1]) / 2 * IMAGE_HEIGHT),
                    ),
                    50,
                    (255, 0, 0),
                    5,
                )

                # Check if hands are in driving up area
                if is_landmarks_in_rectangle(
                    [
                        left_pinky,
                        right_pinky,
                        left_index,
                        right_index,
                        left_thumb,
                        right_thumb,
                    ],
                    **DRIVING_UP_AREA,
                ):
                    events.add("d2_driving_up")

                # Check if hands are turning left or right
                if left_right_hands_slope > self.DRIVING_SLOPE_ANGLE:
                    events.add("d1_driving_left")
                elif left_right_hands_slope < -self.DRIVING_SLOPE_ANGLE:
                    events.add("d1_driving_right")
                else:
                    events.add("d1_driving_default")
            else:
                self.driving_hands = False

            return

    def __str__(self):
        # Convert the arms state to a human-readable string
        return f""  # Add desired string representation here
